import { cn } from '@/lib/utils'

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn('animate-pulse rounded-lg bg-ink-950/8 dark:bg-white/8', className)}
      aria-hidden="true"
    />
  )
}
